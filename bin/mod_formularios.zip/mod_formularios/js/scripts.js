(function($)
{

	$(document).ready(function () {

		$('#form_descarga-promociones-productos').submit(function(e){
			e.preventDefault();
		});



		//FORM NEWSLETTER
		$("#form_newsletter").submit(function(e){
			e.preventDefault();

			var url = $(this).attr("action");
			var id  = $(this).attr("data-id");
			var caja_error = "." + id + "_form_error";

			var femail 		= $('#' + id + '_email').val();

			$('label i',this).remove();

			$(caja_error).empty();
			$('input',this).removeClass('resalta');

			if (femail.length <=5 || ( femail.indexOf("@")<1)) {
				$('#' + id + '_form_email').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu email");
				return false;
				var errores=1;
			};	

			if (errores!=1){
				$("#" + id + " #btn_id_" + id).fadeOut(500);
				$("#" + id + " .loading").show();
				$("#" + id + " #caja_resultado_" + id).animate({opacity:.3});

				var fmodule 	= $('#' + id + '_form_modulo').val();
				var farea 		= $('#' + id + '_form_area').val();
				
				$("input", this).removeClass('resalta');

				$.post( url , {
					email:femail,
					module_id:fmodule,
					area:farea,
					seccion:1
					},
					function(data){
					if (parseInt(data.respuesta)==1){
						$("#" + id + " .loading").hide();
						$("#" + id + " .texto").hide();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1}).empty().append(data.texto_respuesta);
						ga('send', 'event', 'formulario', 'click', 'cita');
					}else{
						$("#" + id + " #btn_id_" + id).show();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .loading").hide();
						alert(data.texto_respuesta);
					}
				},"json");

			}


		});




		//FORM DESCARGA - HOME
		$("#form_form-descarga").submit(function(e){
			e.preventDefault();

			var url = $(this).attr("action");
			var id  = $(this).attr("data-id");
			var caja_error = "." + id + "_form_error";

			var fnombre 	= $('#' + id + '_nombre').val();
			var femail 		= $('#' + id + '_email').val();

			$('label i',this).remove();

			$(caja_error).empty();
			$('input',this).removeClass('resalta');

			if (fnombre.length <=3) {
				$('#' + id + '_form_nombre').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu nombre");
				return false;
				var errores=1;
			};	

			if (femail.length <=5 || ( femail.indexOf("@")<1)) {
				$('#' + id + '_form_email').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu email");
				return false;
				var errores=1;
			};	

			if (errores!=1){
				$("#" + id + " #btn_id_" + id).fadeOut(500);
				$("#" + id + " .loading").show();
				$("#" + id + " #caja_resultado_" + id).animate({opacity:.3});

				var fmodule 	= $('#' + id + '_form_modulo').val();
				var farea 		= $('#' + id + '_form_area').val();
				
				$("input", this).removeClass('resalta');

				$.post( url , {
					nombre:fnombre,
					email:femail,
					module_id:fmodule,
					area:farea,
					seccion:2
					},
					function(data){
					if (parseInt(data.respuesta)==1){
						$("#" + id + " .loading").hide();
						$("#" + id + " .texto").hide();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " #caja_resultado_" + id + " .box_campos").animate({opacity:1}).empty().append(data.texto_respuesta);
						// ga('send', 'event', 'formulario', 'click', 'cita');
					}else{
						$("#" + id + " #btn_id_" + id).show();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .loading").hide();
						alert(data.texto_respuesta);
					}
				},"json");

			}


		});








		//FORM DESCARGA - ASIDE
		$("#form_descarga-promociones-productos").submit(function(e){
			e.preventDefault();

			var url = $(this).attr("action");
			var id  = $(this).attr("data-id");
			var caja_error = "." + id + "_form_error";

			var fnombre 	= $('#' + id + '_nombre').val();
			var femail 		= $('#' + id + '_email').val();

			$('label i',this).remove();

			$(caja_error).empty();
			$('input',this).removeClass('resalta');

			if (fnombre.length <=3) {
				$('#' + id + '_form_nombre').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu nombre");
				return false;
				var errores=1;
			};	

			if (femail.length <=5 || ( femail.indexOf("@")<1)) {
				$('#' + id + '_form_email').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu email");
				return false;
				var errores=1;
			};	

			if (errores!=1){
				$("#" + id + " #btn_id_" + id).fadeOut(500);
				$("#" + id + " .loading").show();
				$("#" + id + " #caja_resultado_" + id).animate({opacity:.3});

				var fmodule 	= $('#' + id + '_form_modulo').val();
				var farea 		= $('#' + id + '_form_area').val();
				
				$("input", this).removeClass('resalta');

				$.post( url , {
					nombre:fnombre,
					email:femail,
					module_id:fmodule,
					area:farea,
					seccion:2
					},
					function(data){
					if (parseInt(data.respuesta)==1){
						$("#" + id + " .loading").hide();
						$("#" + id + " .texto").hide();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1}).empty().append(data.texto_respuesta);
						// ga('send', 'event', 'formulario', 'click', 'cita');
					}else{
						$("#" + id + " #btn_id_" + id).show();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .loading").hide();
						alert(data.texto_respuesta);
					}
				},"json");

			}


		});







		//FORM DESCARGA - HOME
		$("#form_form-sucursales").submit(function(e){
			e.preventDefault();

			var url = $(this).attr("action");
			var id  = $(this).attr("data-id");
			var caja_error = "." + id + "_form_error";

			var fnombre      = $('#' + id + '_nombre').val();
			var femail       = $('#' + id + '_email').val();
			var fcomentarios = $('#' + id + '_comentarios').val();
			var fsucursal    = $('#' + id + '_sucursal').val();

			$('label i',this).remove();

			$(caja_error).empty();
			$('input',this).removeClass('resalta');

			if (fnombre.length <=3) {
				$('#' + id + '_form_nombre').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu nombre");
				return false;
				var errores=1;
			};	

			if (femail.length <=5 || ( femail.indexOf("@")<1)) {
				$('#' + id + '_form_email').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu email");
				return false;
				var errores=1;
			};

			if (errores!=1){
				$("#" + id + " #btn_id_" + id).fadeOut(500);
				$("#" + id + " .loading").show();
				$("#" + id + " #caja_resultado_" + id).animate({opacity:.3});

				var fmodule 	= $('#' + id + '_form_modulo').val();
				var farea 		= $('#' + id + '_form_area').val();
				
				$("input", this).removeClass('resalta');

				$.post( url , {
					nombre:fnombre,
					email:femail,
					comentarios:fcomentarios,
					sucursal:fsucursal,
					module_id:fmodule,
					area:farea,
					seccion:3
					},
					function(data){
					if (parseInt(data.respuesta)==1){
						$("#" + id + " .loading").hide();
						$("#" + id + " #btn_id_" + id).fadeIn(500);
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .contenido_form .texto").empty().append(data.texto_respuesta);
						// ga('send', 'event', 'formulario', 'click', 'cita');
					}else{
						$("#" + id + " #btn_id_" + id).show();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .loading").hide();
						alert(data.texto_respuesta);
					}
				},"json");

			}


		});








		//FORM HAZ UNA CITA - SERVICIOS
		$("#form_agendar-cita-aside").submit(function(e){
			e.preventDefault();

			var url = $(this).attr("action");
			var id  = $(this).attr("data-id");
			var caja_error = "." + id + "_form_error";

			var fnombre 	= $('#' + id + '_nombre').val();
			var femail 		= $('#' + id + '_email').val();
			var ftelefono   = $('#' + id + '_telefono').val();
			var ftaller     = $('#' + id + '_taller').val();
			var fmodelo     = $('#' + id + '_modelo').val();
			var fkilometros = $('#' + id + '_kilometraje').val();
			var fmarca      = $('#' + id + '_marca').val();
			var fproblema   = $('#' + id + '_problema').val();

			$('label i',this).remove();

			$(caja_error).empty();
			$('input',this).removeClass('resalta');

			if (fnombre.length <=3) {
				$('#' + id + '_nombre').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu nombre");
				return false;
				var errores=1;
			};

			if (femail.length <=5 || ( femail.indexOf("@")<1)) {
				$('#' + id + '_email').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu email");
				return false;
				var errores=1;
			};

			if (ftelefono.length <=3) {
				$('#' + id + '_telefono').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu telefono");
				return false;
				var errores=1;
			};

			if (ftaller.length <=1) {
				$('#' + id + '_taller').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu taller de servicio");
				return false;
				var errores=1;
			};

			if (fmodelo.length <=2) {
				$('#' + id + '_modelo').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu modelo de motocicleta");
				return false;
				var errores=1;
			};


			if (errores!=1){
				$("#" + id + " #btn_id_" + id).fadeOut(500);
				$("#" + id + " .loading").show();
				$("#" + id + " #caja_resultado_" + id).animate({opacity:.3});

				var fmodule 	= $('#' + id + '_form_modulo').val();
				var farea 		= $('#' + id + '_form_area').val();
				
				$("input", this).removeClass('resalta');

				$.post( url , {
					nombre:fnombre,
					email:femail,
					telefono:ftelefono,
					taller:ftaller,
					modelo:fmodelo,
					kilometraje:fkilometros,
					marca:fmarca,
					problema:fproblema,
					module_id:fmodule,
					area:farea,
					seccion:4
					},
					function(data){
					if (parseInt(data.respuesta)==1){
						$("#" + id + " .loading").hide();
						$("#" + id + " .texto").hide();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1}).empty().append(data.texto_respuesta);
						// ga('send', 'event', 'formulario', 'click', 'cita');
					}else{
						$("#" + id + " #btn_id_" + id).show();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .loading").hide();
						alert(data.texto_respuesta);
					}
				},"json");

			}


		});






		//FORM COTIZACION PRODUCTO
		$("#form_form-producto").submit(function(e){
			e.preventDefault();

			var url = $(this).attr("action");
			var id  = $(this).attr("data-id");
			var caja_error = "." + id + "_form_error";

			var fnombre   = $('#' + id + '_nombre').val();
			var femail    = $('#' + id + '_email').val();
			var ftelefono = $('#' + id + '_telefono').val();
			var fsucursal = $('#' + id + '_sucursal').val();

			$('label i',this).remove();

			$(caja_error).empty();
			$('input',this).removeClass('resalta');

			if (fnombre.length <=3) {
				$('#' + id + '_form_nombre').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu nombre");
				return false;
				var errores=1;
			};	

			if (femail.length <=5 || ( femail.indexOf("@")<1)) {
				$('#' + id + '_form_email').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu email");
				return false;
				var errores=1;
			};	


			if (ftelefono.length <=3) {
				$('#' + id + '_form_telefono').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu teléfono");
				return false;
				var errores=1;
			};	


			if (errores!=1){
				$("#" + id + " #btn_id_" + id).fadeOut(500);
				$("#" + id + " .loading").show();
				$("#" + id + " #caja_resultado_" + id).animate({opacity:.3});

				var fmodule 	= $('#' + id + '_form_modulo').val();
				var farea 		= $('#' + id + '_form_area').val();
				var fproducto   = $('#' + id + '_form_producto').val();
				
				$("input", this).removeClass('resalta');

				$.post( url , {
					nombre:fnombre,
					email:femail,
					telefono:ftelefono,
					sucursal:fsucursal,
					producto:fproducto,
					module_id:fmodule,
					area:farea,
					seccion:5
					},
					function(data){
					if (parseInt(data.respuesta)==1){
						$("#" + id + " .loading").hide();
						$("#" + id + " #btn_id_" + id).fadeIn(500);
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1}).css("text-align","center").empty().append(data.texto_respuesta);
						// ga('send', 'event', 'formulario', 'click', 'cita');
					}else{
						$("#" + id + " #btn_id_" + id).show();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .loading").hide();
						alert(data.texto_respuesta);
					}
				},"json");

			}


		});






		//FORM COTIZACION PRODUCTO
		$("#form_form-eventos").submit(function(e){
			e.preventDefault();

			var url = $(this).attr("action");
			var id  = $(this).attr("data-id");
			var caja_error = "." + id + "_form_error";

			var fnombre   = $('#' + id + '_nombre').val();
			var femail    = $('#' + id + '_email').val();
			var ftelefono = $('#' + id + '_telefono').val();
			var fevento   = $('#' + id + '_evento').val();

			$('label i',this).remove();

			$(caja_error).empty();
			$('input',this).removeClass('resalta');

			if (fnombre.length <=3) {
				$('#' + id + '_form_nombre').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu nombre");
				return false;
				var errores=1;
			};	

			if (femail.length <=5 || ( femail.indexOf("@")<1)) {
				$('#' + id + '_form_email').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu email");
				return false;
				var errores=1;
			};	

			if (ftelefono.length <=3) {
				$('#' + id + '_form_telefono').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu teléfono");
				return false;
				var errores=1;
			};	

			if (fevento.length <=3) {
				$('#' + id + '_form_evento').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica un evento");
				return false;
				var errores=1;
			};	

			if (errores!=1){
				$("#" + id + " #btn_id_" + id).fadeOut(500);
				$("#" + id + " .loading").show();
				$("#" + id + " #caja_resultado_" + id).animate({opacity:.3});

				var fmodule 	= $('#' + id + '_form_modulo').val();
				var farea 		= $('#' + id + '_form_area').val();
				var fproducto   = $('#' + id + '_form_producto').val();
				
				$("input", this).removeClass('resalta');

				$.post( url , {
					nombre:fnombre,
					email:femail,
					telefono:ftelefono,
					evento:fevento,
					producto:fproducto,
					module_id:fmodule,
					area:farea,
					seccion:6
					},
					function(data){
					if (parseInt(data.respuesta)==1){
						$("#" + id + " .loading").hide();
						$("#" + id + " #btn_id_" + id).fadeIn(500);
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1}).empty().append(data.texto_respuesta);
						// ga('send', 'event', 'formulario', 'click', 'cita');
					}else{
						$("#" + id + " #btn_id_" + id).show();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .loading").hide();
						alert(data.texto_respuesta);
					}
				},"json");

			}


		});		




		//FORM FINANCIAMIENTO
		$("#form_form-financiamiento").submit(function(e){
			e.preventDefault();

			var url = $(this).attr("action");
			var id  = $(this).attr("data-id");
			var caja_error = "." + id + "_form_error";

			var fnombre    = $('#' + id + '_nombre').val();
			var fapellidoP = $('#' + id + '_apellidop').val();
			var fapellidoM = $('#' + id + '_apellidom').val();
			var ftelefono  = $('#' + id + '_telefono').val();
			var focupacion = $('#' + id + '_ocupacion').val();
			var femail     = $('#' + id + '_email').val();
			var fdomicilio = $('#' + id + '_domicilio').val();
			var fcolonia   = $('#' + id + '_colonia').val();
			var fcp        = $('#' + id + '_cp').val();
			var fciudad    = $('#' + id + '_ciudad').val();
			var festado    = $('#' + id + '_estado').val();

			$('label i',this).remove();

			$(caja_error).empty();
			$('input',this).removeClass('resalta');

			if (fnombre.length <=3) {
				$('#' + id + '_form_nombre').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu nombre");
				return false;
				var errores=1;
			};	

			if (fapellidoP.length <=3) {
				$('#' + id + '_form_apellidop').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu apellido");
				return false;
				var errores=1;
			};	

			if (ftelefono.length <=3) {
				$('#' + id + '_form_telefono').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu teléfono");
				return false;
				var errores=1;
			};	

			if (femail.length <=5 || ( femail.indexOf("@")<1)) {
				$('#' + id + '_form_email').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu email");
				return false;
				var errores=1;
			};	

			if (fciudad.length <=3) {
				$('#' + id + '_form_ciudad').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu ciudad");
				return false;
				var errores=1;
			};	

			if (festado.length <=3) {
				$('#' + id + '_form_estado').addClass('resalta').focus();
				$(caja_error).empty().prepend("<span class=\"fa fa-exclamation-triangle\"></span> Por favor indica tu estado");
				return false;
				var errores=1;
			};	



			if (errores!=1){
				$("#" + id + " #btn_id_" + id).fadeOut(500);
				$("#" + id + " .loading").show();
				$("#" + id + " #caja_resultado_" + id).animate({opacity:.3});

				var fmodule 	= $('#' + id + '_form_modulo').val();
				var farea 		= $('#' + id + '_form_area').val();
				
				$("input", this).removeClass('resalta');

				$.post( url , {
					nombre:fnombre,
					apellidoP:fapellidoP,
					apellidoM:fapellidoM,
					telefono:ftelefono,
					ocupacion:focupacion,
					email:femail,
					domicilio:fdomicilio,
					colonia:fcolonia,
					cp:fcp,
					ciudad:fciudad,
					estado:festado,
					module_id:fmodule,
					area:farea,
					seccion:7
					},
					function(data){
					if (parseInt(data.respuesta)==1){
						$("#" + id + " .loading").hide();
						$("#" + id + " #btn_id_" + id).fadeIn(500);
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1}).empty().append(data.texto_respuesta);
						// ga('send', 'event', 'formulario', 'click', 'cita');
					}else{
						$("#" + id + " #btn_id_" + id).show();
						$("#" + id + " #caja_resultado_" + id).animate({opacity:1});
						$("#" + id + " .loading").hide();
						alert(data.texto_respuesta);
					}
				},"json");

			}


		});


	});

})(jQuery);
